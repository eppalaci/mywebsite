# resume 2023

A Pen created on CodePen.io. Original URL: [https://codepen.io/ericapalacio3/pen/BaqErMo](https://codepen.io/ericapalacio3/pen/BaqErMo).

